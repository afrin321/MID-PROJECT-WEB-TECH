<?php

	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Guardian's Home</title>
	<table>
		<tr>
			<td>
				User Name: <?php echo $_COOKIE['name'] ?>
			</td>			
		</tr>
		<tr>
			<td>
				Account Type: <?php echo $_COOKIE['type'] ?>
			</td>			
		</tr>		
	</table>	
</head>
<body>
	<div>  

		<a href="guardianHome.php">Home</a>  |  <a href="guardianAddStudent.php">Add Student</a>  |  <a href="">Enrolled Organizations</a>  |  <a href="">Notice</a>  |  <a href="">Join Organization</a>  |  <a href="">Settings</a>
	</div>



	<form method="post" action="../../php/addStudentByG.php">

		<table>
			<tr>
				<td>
					Search Student with Email
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="email">
				</td>
			</tr>
			<tr>
				<td>
					<input type="submit" name="submit" value="Search">
				</td>
			</tr>

		</table>

		
	</form>

	<div>



	</div>


</body>
</html>