 <?php
	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');	
	require_once('C:/xampp/htdocs/Final Project/service/classService.php');


	$n = getNoticeFromAdmin();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Guardian's Home</title>
	<table>
		<tr>
			<td>
				User Name: <?php echo $_COOKIE['name'] ?>
			</td>			
		</tr>
		<tr>
			<td>
				Account Type: <?php echo $_COOKIE['type'] ?>
			</td>			
		</tr>		
	</table>	
</head>
<body>
	<div>  

		<a href="">Home</a>  |  <a href="guardianAddStudent.php">Add Student</a>  |  <a href="enrolled.php">Enrolled Organizations</a>  |  <a href="guardianNotice.php">Notice</a>  |  <a href="">Join Organization</a>  |  <a href="">Settings</a>
	</div>
	<div>
		<fieldset>
			<legend>Notices</legend>
			<?=$n; ?>
			
		</fieldset>
	</div>

</body>
</html>
