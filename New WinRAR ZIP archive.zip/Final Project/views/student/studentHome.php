<<?php 
echo "Student's home";

 ?>