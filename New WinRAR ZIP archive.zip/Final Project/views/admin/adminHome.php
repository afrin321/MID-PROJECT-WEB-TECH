<?php
	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>
	<table>
		<tr>
			<td>
				User Name: <?php echo $_COOKIE['name'] ?>
			</td>			
		</tr>
		<tr>
			<td>
				Account Type: <?php echo $_COOKIE['type'] ?>
			</td>			
		</tr>		
	</table>	
	
</head>
<body>
	<div>  

		<a href="adminHome.php">Home</a>  |  <a href="classInfo.php">Class</a>  |  <a href="">Students</a>  |  <a href="">Teachers</a>  |  <a href="JoinList.php">Join List</a>  |  <a href="adminNotice.php">Notices</a>
	</div>

</body>
</html>