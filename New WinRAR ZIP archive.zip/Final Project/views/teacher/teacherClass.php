 <?php
	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');	
	require_once('C:/xampp/htdocs/Final Project/php/teacherActivityController.php');	
	$r = getClassList();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Teacher's Homepage</title>
	<table>
		<tr>
			<td>
				User Name: <?php echo $_COOKIE['name'] ?>
			</td>			
		</tr>
		<tr>
			<td>
				Account Type: <?php echo $_COOKIE['type'] ?>
			</td>			
		</tr>		
	</table>	
</head>
<body>
	<div>  

		<a href="teacherHome.php">Home</a>  |  <a href="teacherClass.php">Classes</a>  |  <a href="enrolled.php">Tasks</a>  |  <a href="guardianNotice.php">Notices</a>  |  <a href="">Task Uploads</a>  |  <a href="">Grades</a>
	</div>
	<div>
		<?php echo $r ?>
	</div>

</body>
</html>