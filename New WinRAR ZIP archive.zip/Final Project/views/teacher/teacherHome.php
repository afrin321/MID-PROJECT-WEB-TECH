<<?php 
echo "Teacher's home";

 ?>