<?php

	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');
	require_once('../service/userService.php');

	//echo "hii";
	if (isset($_POST['id'])) {

		
		$email = $_POST['semail'];

		$id = $_POST['id'];
		$r=getidByEmailOthers($email);

		$user = [

			'gid' => $id,
			'sid' => $r['uid']

		];

		$x = addStudentBuGuardian($user);

		if($x) {
			echo "Added";
		}
		 



	}

	if(isset($_POST['email'])){
		//echo "hii again";

		$email=$_POST['email'];
		//echo $email;

		if(empty($email)){
			//echo "empty";
			//header('location: ../views/guardian/guardianAddStudent.php?error=null');
		}
		else{
			$r=getByEmail($email);
			if($r){



				echo "Student is found!";

							//header('location: ../views/guardian/guardianAddStudent.php?isfound=Studentfound');


				
			}else{

				//echo "error";

				//header('location: ../views/guardian/guardianAddStudent.php?error=Studentnotfound');

			}


		}
	}

	if(isset($_POST['name'])){
		//echo "hii";
	$name = $_POST['name'];

	$result = getAllOrg();

	//echo $result[0]['oname'];
	


    $data = "<table border=1>
				<tr>
				    <td>Name</td>
					<td>Phone No. 1</td>
					<td>Phone No. 1</td>
					<td>Email</td>
					<td>Join</td>
				</tr>";

				for($i=0; $i != count($result); $i++ ){ 
			$data .= "<tr>
				<td>".$result[$i]['oname']."</td>
				<td>".$result[$i]['ocno1']."</td>
				<td>".$result[$i]['ocno2']."</td>
				<td>".$result[$i]['oemail']."</td>
				<td>
					<a href=\"edit.php?id=".$result[$i]['oid']."> Join</a> 

				</td>
			</tr>";
		}

	

	$data .= "</table>";

	echo $data;
	}





?>