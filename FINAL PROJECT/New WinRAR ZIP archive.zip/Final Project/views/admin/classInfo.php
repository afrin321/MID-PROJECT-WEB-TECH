<?php
	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>
	<table>
		<tr>
			<td>
				User Name: <?php echo $_COOKIE['name'] ?>
			</td>			
		</tr>
		<tr>
			<td>
				Account Type: <?php echo $_COOKIE['type'] ?>
			</td>			
		</tr>		
	</table>
	<script type="text/javascript" src="adminJS.js"></script>	
</head>
<body>
	<div>  

		<a href="">Home</a>  |  <a href="classInfo.php">Class</a>  |  <a href="">Students</a>  |  <a href="">Teachers</a>  |  <a href="JoinList.php">Join List</a>  |  <a href="">Settings</a>
	</div>

	<div>
		<ul>
			<li><a href="#">Add Class</a></li>
		</ul>
	</div>

	<div>
		<fieldset>
		<legend>Class</legend>
		<form method="post" action="classinfo.php">
			<table>
				<tr>
					<td>
						Class: <select name="class">
							<option></option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							<option value="6">6</option>
							<option value="7">7</option>
							<option value="8">8</option>
							<option value="9">9</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>


						</select>
					</td>
				</tr>
				
				<tr>
					<td>
						Session: <select name="session">
							<option></option>
						<option value="2019-2020">2019-2020</option>
						<option value="2020-2021">2020-2021</option>
					</td>
				</tr>
				
				<tr>
					<td>
						Section: <input type="text" name="section">
					</td>
				</tr>
				<tr>
					<td>
						Subject: <input type="text" name="subject">
					</td>
				</tr>
				<tr>
					<td>
						<input type="button" name="" value="Add Teacher"> <input type="button" name="" value="Add Student">
					</td>
				</tr>
				
				<tr>
					<td>
						<input type="submit" name="create" value="Create Class"> <input type="submit" name="delete" value="Delete Class">
					</td>
				</tr>
			</table> 
		</form>
	</fieldset>
	</div>





</body>
</html>