<?php
	require_once('C:/xampp/htdocs/Final Project/php/sessionController.php');	
?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>
	<table>
		<tr>
			<td>
				User Name: <?php echo $_COOKIE['name'] ?>
			</td>			
		</tr>
		<tr>
			<td>
				Account Type: <?php echo $_COOKIE['type'] ?>
			</td>			
		</tr>		
	</table>	
	
</head>
<body>
	<div>  

		<a href="">Home</a>  |  <a href="classInfo.php">Class</a>  |  <a href="">Students</a>  |  <a href="">Teachers</a>  |  <a href="JoinList.php">Join List</a>  |  <a href="">Settings</a>
	</div>

	<div>
		Activities:
		<ul>
			<li>
				<a href="#" onclick="openStudentList()">View Student List</a>
			</li>
			<li>
				<a href="#">View Teacher List</a>
			</li>
		</ul>
	</div>

	<div id="s_list">
		<table>
			<tr>
				<td>Student Name</td>
				<td>Student DOB</td>
				<td>Guardian Name</td>
				<td>Status</td>
			</tr>
		</table>
		
		
	</div>


	<script type="text/javascript" src="adminJS.js"></script>

</body>
</html>