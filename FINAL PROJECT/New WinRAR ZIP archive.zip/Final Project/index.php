<!DOCTYPE html>
<html>
<head>
	<title>Index page</title>
</head>
<body>

	<h1>landing page</h1>

	<a href="views/login.php">Login</a> |
	<a href="views/signup.php">Signup</a>

</body>
</html>